#! /usr/bin/env python

import datetime, math, string, getopt, sys
import ephem, pytz

usage = """Usage: passtimes.py [OPTION]... SATELLITE 

Mandatory options for long arguments are mandatory for short options too.
  -a, --timeadj=ADJ             adjust times by ADJ seconds when calculating
                                  pass days and groups (morning, evening)
                                  does not affect time in output
                                  (default is -10800 (-3 hours))
  -d, --days=COUNT              do predictions for COUNT days into the future
                                  (default is 7)
  -h, --help                    display this help and exit
  -k, --kepfile=KEPFILE         read TLEs from KEPFILE
                                  (default is kepler.dat)
      --latitude=LATITUDE       latitude of earthstation
                                  (default is +35.302246)
      --longitude=LONGITUDE     longitude of earthstation
                                  (default is -120.665224)
  -t, --time=TIME               begin prediction at TIME
                                  (default is current time)
  -z, --timezone=TIMEZONE       print predictions in local TIMEZONE
                                  (default is US/Pacific)"""



class PassCalculator:
    def __init__(self, observer, sat, time=ephem.now(), tz=pytz.utc, **kwargs):
        self.observer = observer
        self.sat = sat
        self.observer.date = time
        self.tz = tz

    def next_pass(self, time=None):
        if time:
            self.observer.date = time
        self.sat.compute(self.observer)
        p = Pass(self.observer, self.sat, self.tz)
        self.observer.date += 5 * ephem.minute
        return p

class Pass:
    def __init__(self, observer, sat, tz=pytz.utc):
        aos_time = sat.rise_time
        los_time = sat.set_time

        observer.date = aos_time
        sat.compute(observer)
        max_el = sat.alt
        max_time = observer.date

        while observer.date < los_time:
            observer.date += 1 * ephem.second
            sat.compute(observer)
            if sat.alt > max_el:
                max_el = sat.alt
                max_time = observer.date

        self.aos = Coords('AOS', aos_time, observer, sat, tz)
        self.max = Coords('MAX', max_time, observer, sat, tz)
        self.los = Coords('LOS', los_time, observer, sat, tz)

class Coords:
    def __init__(self, name, time, observer, sat, tz):
        self.name = name

        observer.date = time
        sat.compute(observer)
        t = time.tuple()

        self.time = datetime.datetime(
                t[0],                           # year
                t[1],                           # month
                t[2],                           # day
                t[3],                           # hour
                t[4],                           # minute
                int(t[5]),                      # second
                #int(t[5] * 1000000) % 1000000,  # microseconds
                0,  # microseconds seem unnecessary
                pytz.utc                        # UTC timezone
            ) 
        self.az = math.degrees(sat.az)
        self.el = math.degrees(sat.alt)
        self.range = sat.range / 1000.0     # kilometers
        self.tz = tz

    def __str__(self):
        t = self.time.astimezone(self.tz)
        dt = t.utcoffset()
        hours = dt.days * 24 + dt.seconds / 3600
        return '|| %s: || %s %s (%+d:00) || %.1f || %.1f || %d ||' % \
            (self.name, t.time(), t.tzname(), hours, self.az, self.el, self.range)


if __name__ == '__main__':
    # default parameters
    adj             = datetime.timedelta(0, -3 * 60 * 60)
    day_count       = 7
    kepfile         = 'kepler.dat'
    location        = ephem.Observer()
    location.lat    = '+35.302246'
    location.long   = '-120.665224'
    start_time      = ephem.now()
    loc             = pytz.timezone('US/Pacific')
    satname         = None
    tle1            = None
    tle2            = None

    # parse command-line
    try:
        opts, args = getopt.gnu_getopt(sys.argv[1:], 'a:d:hk:t:z:',
            ['timeadj=', 'days=', 'help', 'kepfile=', 'latitude=', \
            'longitude=', 'time=', 'timezone='])
    except getopt.GetoptError, e:
        sys.stderr.write('passtimes.py: ' + str(e) + '\n')
        sys.exit(1)

    # handle options
    for (opt, val) in opts:
        if opt == '-a' or opt == '--timeadj':
            try:
                adj = datetime.timedelta(0, int(val))
            except ValueError:
                sys.stderr.write('passtimes.py: -a, --timeadj argument must be a valid integer\n')
                sys.exit(1)
        elif opt == '-d' or opt == '--days':
            try:
                day_count = int(val)
            except ValueError:
                sys.stderr.write('passtimes.py: -d, --days argument must be a valid integer\n')
                sys.exit(1)
        elif opt == '-h' or opt == '--help':
            print usage
            sys.exit(0)
        elif opt == '-k' or opt == '--kepfile':
            kepfile = val
        elif opt == '--latitude':
            location.lat = val
        elif opt == '--longitude':
            location.long = val
        elif opt == '-t' or opt == '--time':
            start_time = ephem.date(val)
        elif opt == '-z' or opt == '--timezone':
            loc = pytz.timezone(val)

    if len(args) > 0:
        satname = args[0]
    else:
        sys.stderr.write('passtimes.py: missing satellite operand\n')
        sys.stderr.write("Try `passtimes.py --help' for more information\n")
        sys.exit(1)

    # read kepfile
    try:
        f = file(kepfile, 'r')
    except IOError:
        sys.stderr.write('passtimes.py: could not open ' + kepfile + '\n')
        sys.exit(1)

    l = f.readline().strip()
    while l:
        if l == satname:
            tle1 = f.readline().strip()
            tle2 = f.readline().strip()
            break
        l = f.readline().strip()
    f.close()
    
    if not (tle1 and tle2):
        sys.stderr.write('passtimes.py: ' + satname + ' not found in kepler.dat\n')
        sys.exit(1)

    # calculate pass times
    satellite   = ephem.readtle(satname, tle1, tle2)
    calc        = PassCalculator(location, satellite, start_time, loc)
    noon        = datetime.time(12)
    cur_date    = None
    cur_set     = None
    pass_count  = 0

    print 'Last updated using the following TLE:'
    print '{{{'
    print satname
    print tle1
    print tle2
    print '}}}'
    print

    while True:
        p = calc.next_pass()
        adj_time = (p.aos.time + adj).astimezone(loc)
        date = adj_time.date()
        time = adj_time.time()

        if time < noon:
            set = 'Morning'
        else:
            set = 'Evening'

        if date != cur_date:
            day_count -= 1
            if day_count < 0:
                break
            cur_date = date
            print cur_date.strftime('== %a, %d-%b-%Y ==')

        if set != cur_set:
            pass_count = 0
            cur_set = set
            print '=== %s ===' % cur_set

        if pass_count:
            print '|| ' * 6
        else:
            print "|| || '''Time''' || '''Az''' || '''El''' || '''Range''' ||"
        pass_count += 1

        print p.aos
        print p.max
        print p.los
